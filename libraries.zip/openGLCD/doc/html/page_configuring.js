var page_configuring =
[
    [ "Specifying Pins", "page_pindefines.html", null ]
];