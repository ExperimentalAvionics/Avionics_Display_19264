var searchData=
[
  ['centerx',['CenterX',['../classglcd.html#aa8546e0626837aeeeee6de4c7bee0f63',1,'glcd']]],
  ['centery',['CenterY',['../classglcd.html#a2203e004a9de1456ea6a80cdbd47d1e9',1,'glcd']]],
  ['charheight',['CharHeight',['../classg_text.html#a785d25776c45aa7753128148b01c6dfc',1,'gText']]],
  ['charwidth',['CharWidth',['../classg_text.html#a7e4b403b3868c86bdb9cc57457e6cf2f',1,'gText']]],
  ['cleararea',['ClearArea',['../classg_text.html#a1ea15a8a8afeeaeac257e4f7f150a600',1,'gText']]],
  ['clearareamode',['ClearAreaMode',['../classg_text.html#ac975d5f2d87a7cd394cd1f4509ae7a94',1,'gText']]],
  ['clearscreen',['ClearScreen',['../classglcd.html#a7e9ad878672abdfef9f0d7604c10a9bc',1,'glcd']]],
  ['cursorto',['CursorTo',['../classg_text.html#ac366699316d2f65ec64fbeb3d08a64cd',1,'gText::CursorTo(uint8_t column, uint8_t row)'],['../classg_text.html#a37ca432d191df8afff249f4a5e5f7e7f',1,'gText::CursorTo(int8_t column)']]],
  ['cursortoxy',['CursorToXY',['../classg_text.html#ab03435103b60b44ae0db9e6b8cd7f172',1,'gText']]],
  ['configuration',['Configuration',['../page_configuring.html',1,'index']]]
];
