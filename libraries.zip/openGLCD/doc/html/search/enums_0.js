var searchData=
[
  ['eraseline_5ft',['eraseLine_t',['../group__glcd__enum.html#gae849cc01d60a535299bbb59a22b68bc4',1,'gText.h']]]
];
