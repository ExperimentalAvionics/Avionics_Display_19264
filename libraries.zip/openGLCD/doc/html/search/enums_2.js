var searchData=
[
  ['predefinedarea',['predefinedArea',['../group__glcd__enum.html#ga7c9059506d7e1ad7da54dd3a5cd7d8ff',1,'gText.h']]]
];
