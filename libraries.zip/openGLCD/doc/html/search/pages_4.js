var searchData=
[
  ['glcd_20coordinate_20system',['GLCD coordinate system',['../page_coordinates.html',1,'page_GLCD_API']]],
  ['glcd_20object_20api_20functions',['GLCD object API functions',['../page__g_l_c_d_object.html',1,'page_GLCD_API']]],
  ['gtext_20api_20functions',['gText API functions',['../page_g_text_object.html',1,'page_GLCD_API']]]
];
