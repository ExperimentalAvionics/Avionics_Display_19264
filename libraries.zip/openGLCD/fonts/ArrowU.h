

/*
 *
 * ArrowU
 *
 * created with FontCreator
 * written by F. Maximilian Thiele
 *
 * http://www.apetech.de/fontCreator
 * me@apetech.de
 *
 * File Name           : ArrowU.h
 * Date                : 12.09.2015
 * Font size in bytes  : 167
 * Font width          : 10
 * Font height         : -16
 * Font first char     : 37
 * Font last char      : 38
 * Font used chars     : 1
 *
 * The font data are defined as
 *
 * struct _FONT_ {
 *     uint16_t   font_Size_in_Bytes_over_all_included_Size_it_self;
 *     uint8_t    font_Width_in_Pixel_for_fixed_drawing;
 *     uint8_t    font_Height_in_Pixel_for_all_characters;
 *     unit8_t    font_First_Char;
 *     uint8_t    font_Char_Count;
 *
 *     uint8_t    font_Char_Widths[font_Last_Char - font_First_Char +1];
 *                  // for each character the separate width in pixels,
 *                  // characters < 128 have an implicit virtual right empty row
 *
 *     uint8_t    font_data[];
 *                  // bit field of all characters
 */

#ifndef ARROWU_H
#define ARROWU_H

#define ARROWU_WIDTH 10
#define ARROWU_HEIGHT -16

GLCDFONTDECL(ArrowU) = {
    0x00, 0xA7, // size
    0x0A, // width
    0xF0, // height
    0x25, // first char
    0x01, // char count
    
    // char widths
    0x0A, 
    
    // font data
    0x00, 0x10, 0x18, 0x1C, 0xFE, 0xFE, 0x1C, 0x18, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F, 0x1F, 0x00, 0x00, 0x00, 0x00 // 37
    
};

#endif
