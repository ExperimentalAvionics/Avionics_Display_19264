

/*
 *
 * Arrows
 *
 * created with FontCreator
 * written by F. Maximilian Thiele
 *
 * http://www.apetech.de/fontCreator
 * me@apetech.de
 *
 * File Name           : Arrows.h
 * Date                : 12.09.2015
 * Font size in bytes  : 320
 * Font width          : 10
 * Font height         : 13
 * Font first char     : 37
 * Font last char      : 39
 * Font used chars     : 2
 *
 * The font data are defined as
 *
 * struct _FONT_ {
 *     uint16_t   font_Size_in_Bytes_over_all_included_Size_it_self;
 *     uint8_t    font_Width_in_Pixel_for_fixed_drawing;
 *     uint8_t    font_Height_in_Pixel_for_all_characters;
 *     unit8_t    font_First_Char;
 *     uint8_t    font_Char_Count;
 *
 *     uint8_t    font_Char_Widths[font_Last_Char - font_First_Char +1];
 *                  // for each character the separate width in pixels,
 *                  // characters < 128 have an implicit virtual right empty row
 *
 *     uint8_t    font_data[];
 *                  // bit field of all characters
 */

#ifndef ARROWS_H
#define ARROWS_H

#define ARROWS_WIDTH 10
#define ARROWS_HEIGHT 13

GLCDFONTDECL(Arrows) = {
    0x01, 0x40, // size
    0x0A, // width
    0x0D, // height
    0x25, // first char
    0x02, // char count
    
    // char widths
    0x0D, 0x0B, 
    
    // font data
    0x00, 0x00, 0x10, 0x18, 0x1C, 0x1E, 0xFF, 0xFF, 0x1E, 0x1C, 0x18, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, // 37
    0x00, 0x20, 0x60, 0xE0, 0xE0, 0xFF, 0xFF, 0xE0, 0xE0, 0x60, 0x20, 0x00, 0x00, 0x00, 0x00, 0x08, 0x18, 0x18, 0x08, 0x00, 0x00, 0x00 // 38
    
};

#endif
