//
// openGLCD build information
// This headerfile is automatically generated
//

#ifndef __openGLCD_Buildinfo_h__
#define __openGLCD_Buildinfo_h__

#define GLCD_GLCDLIB_BUILD_DATESTR	"Sun Mar 08 19:50:44 CDT 2015"
#define GLCD_GLCDLIB_BUILD_REVSTR	"1.0rc2"
#define GLCD_GLCDLIB_BUILD_BUILDSTR	"v1.0rc2"
#endif
